<?php 
/**
**/
defined( '_JEXEC' ) or die( 'Restricted access' );


class flexicontent_html_custom
{
	
static function printicon( $print_link, &$params )
	{

$flexi_iconpath = 'images/icons/';

// print icon
if ( $params->get('show_print_icon') || JRequest::getCmd('print') ) {

			$print_status = 'status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=640,height=480,directories=no,location=no';

			// checks template image directory for image, if non found default are loaded
			if ( $params->get( 'show_icons' ) ) {
				$print_image = FLEXI_J16GE ?
					JHTML::image( $flexi_iconpath.'printButton.png', JText::_( 'FLEXI_PRINT' )) :
					JHTML::_('image.site', 'printButton.png', $flexi_iconpath, NULL, NULL, JText::_( 'FLEXI_PRINT' )) ;
			} 
			
			if (JRequest::getInt('pop')) {
				//button in popup
				$html_print_icon = '<a href="javascript:;" onclick="window.print();return false;">'.$print_image.'</a>';
			} else {
				//button in view
				$print_overlib = JText::_( 'FLEXI_PRINT_TIP' );
				$print_text = JText::_( 'FLEXI_PRINT' );
                $html_print_icon = '<a href="'. JRoute::_($print_link) .'" class="print-icon editlinktip hasTip" onclick="window.open(this.href,\'win2\',\''.$print_status.'\'); return false;" title="'.$print_text.'::'.$print_overlib.'">'.$print_image.'</a>';
			}
			return $html_print_icon;
    }
	return;
}
	/**
	 * Creates the rss feed button
	 *
	 * @param string $print_link
	 * @param array $params
	 * @since 1.0
	 */
static function feedicon($view, &$params, $slug = null, $itemslug = null )
{
$flexi_iconpath = 'images/icons/';

// Feed Button
if ( $params->get('show_feed_icon', 1) && !JRequest::getCmd('print') ) {
			
			$uri    = JURI::getInstance();
			$base  	= $uri->toString( array('scheme', 'host', 'port'));

			//TODO: clean this static stuff (Probs when determining the url directly with subdomains)
			if($view == 'category') {
				$feed_link 	= $base.JRoute::_( 'index.php?view='.$view.'&cid='.$slug.'&format=feed&type=rss', false );
			} elseif($view == FLEXI_ITEMVIEW) {
				$feed_link 	= $base.JRoute::_( 'index.php?view='.$view.'&cid='.$slug.'&id='.$itemslug.'&format=feed&type=rss', false );
			} elseif($view == 'tags') {
				$feed_link 	= $base.JRoute::_( 'index.php?view='.$view.'&id='.$slug.'&format=feed&type=rss', false );
			} else {
				$feed_link	= $base.JRoute::_( 'index.php?view='.$view.'&format=feed&type=rss', false );
			}
			// Fix for J1.7+ format variable removed from URL and added as URL suffix
			if (!preg_match('/format\=feed/',$feed_link)) {
				$feed_link .= "&amp;format=feed";
			}

			$feed_status = 'status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=800,height=600,directories=no,location=no';

			if ($params->get('show_icons')) 	{
				$feed_image = FLEXI_J16GE ?
                    JHTML::image( $flexi_iconpath.'livemarks.png', JText::_( 'FLEXI_FEED' )) :
					JHTML::_('image.site', 'livemarks.png', $flexi_iconpath, NULL, NULL, JText::_( 'FLEXI_FEED' )) ;
			} else {
				$feed_image = '&nbsp;'.JText::_( 'FLEXI_FEED' );
			}

			$feed_overlib = JText::_( 'FLEXI_FEED_TIP' );
			$feed_text = JText::_( 'FLEXI_FEED' );
			$html_feed_icon = '<a href="'. $feed_link .'" class="feed-icon editlinktip hasTip" onclick="window.open(this.href,\'win2\',\''.$feed_status.'\'); return false;" title="'.$feed_text.'::'.$feed_overlib.'">'.$feed_image.'</a>'; 
			return $html_feed_icon;
			}
		return;	
}

	/**
	 * Creates the email button
	 *
	 * @param string $print_link
	 * @param array $params
	 * @since 1.0
	 */
static function emailicon($view, &$params, $slug = null, $itemslug = null )
{
$flexi_iconpath = 'images/icons/';

// Email Button 
		static $initialize = null;
		static $uri, $base;

		if ( !$params->get('show_email_icon') || JRequest::getCmd('print') ) return;

		if ($initialize === null) {
			if (file_exists ( JPATH_SITE.DS.'components'.DS.'com_mailto'.DS.'helpers'.DS.'mailto.php' )) {
				require_once(JPATH_SITE.DS.'components'.DS.'com_mailto'.DS.'helpers'.DS.'mailto.php');
				$uri  = JURI::getInstance();
				$base = $uri->toString( array('scheme', 'host', 'port'));
				$initialize = true;
			} else {
				$initialize = false;
			}
		}
		if ( $initialize === false ) return;
		//TODO: clean this static stuff (Probs when determining the url directly with subdomains)
		if($view == 'category') {
			$email_link = $base . JRoute::_(FlexicontentHelperRoute::getCategoryRoute($slug));
			//$link = $base . JRoute::_( 'index.php?view='.$view.'&cid='.$slug, false );
		} elseif($view == FLEXI_ITEMVIEW) {
			$email_link = $base . JRoute::_(FlexicontentHelperRoute::getItemRoute($itemslug, $slug));
			//$link = $base . JRoute::_( 'index.php?view='.$view.'&cid='.$slug.'&id='.$itemslug, false );
		} elseif($view == 'tags') {
			$email_link = $base . JRoute::_(FlexicontentHelperRoute::getTagRoute($itemslug));
			//$link = $base . JRoute::_( 'index.php?view='.$view.'&id='.$slug, false );
		} else {
			$email_link 	= $base . JRoute::_( 'index.php?view='.$view, false );
		}

		$email_url 	= 'index.php?option=com_mailto&tmpl=component&link='.MailToHelper::addLink($email_link);

		$email_status = 'status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=500,height=600,directories=no,location=no';

		if ($params->get('show_icons')) 	{
			$email_image = FLEXI_J16GE ?
				JHTML::image( $flexi_iconpath.'emailButton.png', JText::_( 'FLEXI_EMAIL' )) :
				JHTML::_('image.site', 'emailButton.png', $flexi_iconpath, NULL, NULL, JText::_( 'FLEXI_EMAIL' )) ;
		} else {
			$email_image = '&nbsp;'.JText::_( 'FLEXI_EMAIL' );
		}

		$email_overlib = JText::_( 'FLEXI_EMAIL_TIP' );
		$email_text = JText::_( 'FLEXI_EMAIL' );
		$html_email_icon	= '<a href="'. JRoute::_($email_url) .'" class="email-icon editlinktip hasTip" onclick="window.open(this.href,\'win2\',\''.$email_status.'\'); return false;" title="'.$email_text.'::'.$email_overlib.'">'.$email_image.'</a>';
		return $html_email_icon;

  }
}
//  Ende init Buttons  angepasste Funtionen aus Flexicontent Helper. Imagepath
?>

