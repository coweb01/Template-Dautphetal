<?php 
/********************************************************************* 
 * Template  
 * Template Joomla 3 014 
 * Kunde: 
 * Author:  Claudia Oerter  
 * Stand:   10/2013 
 * Version:  
 * copyright Template das webconcept 
 * Die Fehlerseite muss in den Templateparametern ausgewählt werden.
 *  
 *******************************************************************/
  
defined( '_JEXEC' ) or die; 
JHTML::_('behavior.framework', true); 
$app                      = JFactory::getApplication();
$doc                      = JFactory::getDocument();
$params                   = $app->getTemplate(true)->params; // Templateparameter
$url                      = JURI::base(); 
$errorsite                = $params->get('errorsite');
if ( isset ($errorsite )) {
				$url_notfound             = JRoute::_($item->link . '&Itemid=' . $errorsite); 
} 


?> 
<html> 
<body> 
  
<?php if ($this->error->getCode()>=400 && $this->error->getCode() <= 500) {  
JApplication::redirect($url_notfound );  
} else { 
JApplication::redirect($url_notfound );  
} 
?> 
</body> 
</html>