<?php
/**
 * @package		Joomla.Site
 * @subpackage	mod_menu
 * @copyright	Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 * Override für Inhaltsverzeichniss
 */

// No direct access.
defined('_JEXEC') or die;

// Note. It is important to remove spaces between elements.

if ((count($list)) > 0) { 
  $count = count($list);
  $anzcols = (count($list)/2);
  if (($anzcols%2)!=0) { $anzcols++; }
}
$column = 1;
$level  = 1;
$countitems  = $count;
?>
<!-- Start Sitemap -->
<div <?php
	$tag = '';
	if ($params->get('tag_id')!=NULL) {
		$tag = $params->get('tag_id').'';
		echo ' id="'.$tag.'"';
	}
?>>



<?php
   foreach ($list as $i => &$item) :
	
	if ($count >= $anzcols && $level == 1) {
		$count = 0;
		if ($column > 1) { echo "</ul></div>\n";}
		echo '<div class="sitemapcol'. $column .'"><ul>'."\n";
		$column++;
	}
	
	$class = 'item-'.$item->id;

	if ($item->id == $active_id) {
		$class .= ' current';
	}

	if (in_array($item->id, $path)) {
		$class .= ' active';
	}
	elseif ($item->type == 'alias') {
		$aliasToId = $item->params->get('aliasoptions');
		if (count($path) > 0 && $aliasToId == $path[count($path)-1]) {
			$class .= ' active';
		}
		elseif (in_array($aliasToId, $path)) {
			$class .= ' alias-parent-active';
		}
	}

	if ($item->deeper) {
		$class .= ' deeper';
	}

	if ($item->parent) {
		$class .= ' parent';
	}

	if (!empty($class)) {
		$class = ' class="'.trim($class) .'"';
	}
	
	echo '<li'.$class.'>';

	


	// Render the menu item.
	switch ($item->type) :
		case 'separator':
		case 'url':
		case 'component':
			require JModuleHelper::getLayoutPath('mod_menu', 'sitemap_'.$item->type);
			break;

		default:
			require JModuleHelper::getLayoutPath('mod_menu', 'sitemap_url');
			break;
	endswitch;
	

	// The next item is deeper.
	if ($item->deeper) {
	$level++;
	echo "\n<ul>";
	}
	// The next item is shallower.
	elseif ($item->shallower) {
		$level = $level -1;
		echo "</li>\n";
		echo str_repeat("</ul></li>\n", $item->level_diff);
	}
	// The next item is on the same level.
	else {
		echo "</li>\n";
	}
$count++;	
endforeach;
?>
</ul></div>
<!-- Ende Sitemap-->
</div>


