<?php
if (count(JModuleHelper::getModules('frontpage')) > 0 ) :
							/* Modul Frontpage mehrspaltig */
						 	$cols_frontpage = $this->params->get('sp_frontpage');
							$modules  = JModuleHelper::getModules('frontpage');
							$style    = 'xhtml'; 
							$position = 'frontpage';
							$count = count($modules);
							$countercol = 1;
							$i = 0;
						
								if ($cols_frontpage == 1) :?>
									<div id="frontpage" class="cols<?php echo $cols_frontpage; ?> <?php echo $classbootstraprow; ?>">
										<div class="col1 span12">
											<jdoc:include type="modules" name="frontpage" style="rounded"/> <!-- modul position frontpage -->
										</div>
									</div>
		
								<?php else : ?>
								
									<div id="frontpage" class="cols<?php echo $cols_frontpage; ?> <?php echo $classbootstraprow.' span'.$frontpageRowWidth; ?>">
		                                        
										<?php
										$rows = (int) ceil($count / $cols_frontpage);
										if ($bootstrap_layout == 1 ) {
											// fluid
											$spanWidth = 12 / $cols_frontpage;
										} else {
											// not fluid => TODO: fix!
											$spanWidth = $frontpageRowWidth / $cols_frontpage;
										}
									
										// class von row div $classbootstraprow
										$classes = '';
										$numDummies = ($rows * $cols_frontpage) - $count;
										for ($a = 0; $a < $count; $a++) :
											if ($a % $cols_frontpage == 0): ?>
												<?php if($bootstrap):?>
													<div class="<?php echo $classbootstraprow; ?>">
												<?php else: 
													// falls kein bootstrap
												endif;?>
											<?php endif;
											// in welcher spalte? -> an $classes dran hängen.
											$modulo = ($a + 1) % $cols_frontpage;
											if ($modulo == 0): 
												//col1 oder col2 oder col3 je nachdem
												$classes .= 'col'.$cols_frontpage.' ';
											else:
												$classes .= 'col'.$modulo.' ';
											endif;
											
											// jetzt $spanWidth dran -> spezialfall beachten
											if ($bootstrap){
											if ($spanWidth != 4.5):
												$classes .= 'span'.$spanWidth.' ';
											else:
												$classes .= 'span4 ';
											endif; 
											} else {
												// bootstrap => mit span etc. hier not fluid
											}?>
											
											<?php // jetzt die module in die divs packen -> spezialfall beachten  ?>
											<div class="<?php echo $classes; ?>">
												<?php echo JModuleHelper::renderModule($modules[$a], array(
													'style' => $style,
													'position' => $position,
												 	)); ?> 
										 	</div>
										 	
										 	<?php // zeile mit dummies auffüllen! TODO: mit nicht fluid anpassen -> colsX anpassen
										 		// TODO: if aus for rausbekommen (checken mit nicht fluid)
										 		if($a == ($count - 1)) {
													// wenn for "fertig" ist dummies einfügen
													for ($b = 0; $b < $numDummies; $b++) { ?>
													<div class="dummy <?php echo 'span'.$spanWidth; ?>"></div>
													<?php }
												}
											?>
											<?php if ($spanWidth == 4.5 && ($a + 1) % $cols_frontpage == 0): ?>
												<div <?php if ($bootstrap) echo 'class="span1"'; ?>></div>
											<?php endif; 
											
											if ($a % $cols_frontpage == 1): ?>
												</div>
											<?php endif;
											$classes = '';
										endfor;?>
									</div>
								<?php endif; ?>
							<?php endif; ?>