<?php
header ("content-type: text/css");
//$css = file_get_contents('http://fonts.googleapis.com/css?family=Open+Sans:400,600,700,300');
$css .= file_get_contents('../../co_freiensteinau_25/css/layout.css' );
$css .= file_get_contents('../../co_freiensteinau_25/css/flexicontent_custom.css');
$css .= file_get_contents('../../co_freiensteinau_25/css/template_sys.css' );
$css .= file_get_contents('../../co_freiensteinau_25/css/template.css');
$css .= file_get_contents('../../co_freiensteinau_25/css/basic.css');
$css .= file_get_contents('../../co_freiensteinau_25/css/menue.css');
$css .= file_get_contents('../../co_freiensteinau_25/css/formulare.css');
$css .= file_get_contents('../../co_freiensteinau_25/css/editor.css');
$css .= file_get_contents('../../co_freiensteinau_25/css/responsive.css');

echo $css;
?>