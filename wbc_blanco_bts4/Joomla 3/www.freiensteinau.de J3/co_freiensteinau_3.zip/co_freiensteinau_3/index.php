<?php
/**********************************************************
 * Template co_freiensteinau_3
 * Template Joomla 3
 * Kunde:     Gemeinde Freiensteinau
 * Authoren:  Claudia Oerter  
 * Stand:     Februar 2015
 * Version:   J3.01 
 * copyright Template das webconcept
 **********************************************************/
defined( '_JEXEC' ) or die; 
JHTML::_('behavior.framework', true);
$this->setMetaData('generator','');
jimport( 'joomla.application.module.helper' );
$app                      = JFactory::getApplication();
$doc                      = JFactory::getDocument(); 
$classbootstraprow        = ""; 
$classbootstrapcontainer  = "";
$params                   = $app->getParams();
$pageclass                = $params->get('pageclass_sfx'); // parameter (menu entry)
$tpath                    = $this->baseurl.'/templates/'.$this->template;
$module                   = JModuleHelper::getModule( 'mod_maximenuck' );
$activeModuleId           = $module->id;

/** Frontpage und aktiven Menuepunkt  ermitteln *****/
$menu                     = $app->getMenu();
$activeMenu               = $menu->getActive(); // aktive Menue
$activeMenuId             = $activeMenu->id;    // aktive Menue ID 
$activeMenuTitle          = $activeMenu->title; // aktiven Menuetitel
$classbootstraprow        = "row-fluid";
$classbootstrapcontainer  = "container";


if ( $menu->getActive() == $menu->getDefault()) :    // startseite nur sinnvoll wenn ohne mehrspachigkeit
	  $frontpage = 1;
	  $classfront = 'class="front"';
else: 
	 $frontpage = 0;
	 $classfront  = 'class="nofront"';

endif;	  

/****  Get Templateparams    ***************************************************/        
$templateparams        = $app->getTemplate(true)->params;
if ($frontpage == 1) { 
	$showleftColumn        = $this->countModules('leftpos1 or leftpos2 or Navleft or searchleft');
	$showrightColumn       = $this->countModules('rightpos1 or rightpos2 or infobox');
} else {
	$showleftColumn        = $this->countModules('leftpos1 or leftpos2 or Navleft');
	$showrightColumn       = $this->countModules('rightpos1 or rightpos2 or infobox');
} 

$modernizr             = $templateparams->get('modernizr');
$flexicontent          = $templateparams->get('flexicontent', 0);
$footable              = $templateparams->get('footable', 0);
$jquery                = $templateparams->get('jquery', 0);

if ($templateparams->get('jquery_local') ):
			$jqueryurl =  'media/co_freiensteinau_25/' . $templateparams->get('jquery_local');
	        else :
			$jqueryurl =  $templateparams->get('jquery_host');
endif;

$classbootstrap    = "span12";
// same ans $classbootstrap just without the span
$frontpageRowWidth = 12;
if(($showleftColumn) || ($showrightColumn)) : 
					 $classbootstrap    = 9;
					 $frontpageRowWidth = 9;
endif;	

if(($showleftColumn) && ($showrightColumn)) : 
					 $classbootstrap    = 6;
					 $frontpageRowWidth = 6;
endif;


//if(!$app->jquery){
//if ( $jquery == 1 ) :  // JQuery einbinden
//	  $doc->addScript( $jqueryurl );
//	  $doc->addScript('media/co_freiensteinau_25/noConflict.js');
//	  $app->jquery = true;
// endif;
//} 
JHtmlBootstrap::loadCss();
$doc->addStyleSheet($tpath . '/css/styles.php');

if ($footable == 1) { 
	$doc->addStyleSheet($tpath . '/footable/css/footable.core.css');
} 


JHtml::_('bootstrap.framework');	


// Meta data

if ($bootstrap_responsive == 1) { $this->setMetaData("viewport", "width=device-width, initial-scale=1, maximum-scale=2.0");  } // only for mobil devices and responsive template
$this->setMetaData("generator","");

?>
<!DOCTYPE html>
<!--[if IEMobile]><html class="iemobile" lang="<?php echo $this->language; ?>"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8" lang="<?php echo $this->language; ?>"> <![endif]-->
<!--[if gt IE 8]><!-->  <html class="no-js" lang="<?php echo $this->language; ?>"> <!--<![endif]-->

<!-- ****************************************************************************************************** -->
<!-- *     Head                                                                                           * -->
<!-- ****************************************************************************************************** -->  
<head>

    <jdoc:include type="head" />
    
	<link rel="apple-touch-icon" href="<?php echo $tpath; ?>/images/apple-touch-icon-precomposed.png"/>
    <link rel="apple-touch-icon-precomposed" href="<?php echo $tpath; ?>/images/apple-touch-icon-57x57-precomposed.png">
	<link rel="apple-touch-icon-precomposed" sizes="76x76" href="<?php echo $tpath; ?>/images/apple-touch-icon-76x76-precomposed.png">
	<link rel="apple-touch-icon-precomposed" sizes="120x120" href="<?php echo $tpath; ?>/images/apple-touch-icon-120x120-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="152x152" href="<?php echo $tpath; ?>/images/apple-touch-icon-152x152-precomposed.png" />

   
    <?php  if ($modernizr==1) $doc->addScript($tpath.'/js/modernizr-2.6.2.js'); // <- this script must be in the head ?>



    <!-- IE6 & IE7 css include -->
    <!--[if lte IE 6]>
            <link href="<?php echo $tpath; ?>/css/ie6only.css" rel="stylesheet" type="text/css" />
        <![endif]-->
    <!--[if IE 7]>
            <link href="<?php echo  $tpath; ?>/css/ie7only.css" rel="stylesheet" type="text/css" />
        <![endif]-->
    <!--[if IE 8]>
            <link href="<?php echo  $tpath; ?>/css/ie8only.css" rel="stylesheet" type="text/css" />
    <![endif]-->

    <!--[if lt IE 9]>
    <script src="<?php echo $this->baseurl ?>/media/jui/js/html5.js"></script>
    <![endif]-->
    

</head>
<!-- ############################# end html head ###################################################################################-->


<!-- ############################# start html body ###################################################################################-->
<body <?php echo $classfront; ?>>
	<div id="seitenanfang" class="wrap-outer container">   <!-- start wrapper global -->
	
    <!-- outdated browser warning -->
    <?php if ($this->params->get('browsermsg') == 1 ) : ?>    
       <!--[if lt IE 8]>
        <div id="info">
        	<a href="#" onClick="ShowInfobox(); return false"><img class="info" src="<?php echo $tpath;?>/images/info.png" alt="Wichtige Information" title="Wichtige Information"></a>
        </div>
        
        <div id="browsermsg"> 
	        <p id="close">
	        	<img src="<?php echo $tpath;?>/images/close-i.png" alt="Schliessen" />
	        </p>
	        
	        <p>
	        	<?php echo $this->params->get('infomsg')?>
	        </p>
	        
	        <p>
	        	<a href="<?php echo $this->params->get('linkie')?>"  target="_blank">Update Internet Explorer</a>
	        </p>
	        
	        <p>
	        	<a href="<?php echo $this->params->get('linkfirefox')?>"  target="_blank">Installation Firefox</a>
	        </p>
        </div>
        <![endif]-->
    <?php endif; ?>

		<!-- start Accesibility  -->
		<h1 class="u2">Navigation</h1>
		<ul class="unsichtbar">
			<li><a href="#content" class="u2"><?php echo JText::_('TPL_CO_FREIENSTEINAU_3_Skip_to_Content'); ?></a></li>
			<li><a href="#mainmenu" class="u2"><?php echo JText::_('TPL_CO_FREIENSTEINAU_3_Jump_to_Main_Navigation'); ?></a></li>
			<li><a href="#menutop" class="u2"><?php echo JText::_('TPL_CO_FREIENSTEINAU_3_Jump_to_Top_Navigation'); ?></a></li>
			<li><a href="#left" class="u2"><?php echo JText::_('TPL_CO_FREIENSTEINAU_3_Jump_to_left_additional_Information'); ?></a></li>
			<li><a href="#right" class="u2"><?php echo JText::_('TPL_CO_FREIENSTEINAU_3_Jump_to_right_additional_Information'); ?></a></li>
			<li><a href="#suchen" class="u2"><?php echo JText::_('TPL_CO_FREIENSTEINAU_3_Jump_to_search'); ?></a></li>
		</ul>
		<!-- end Accesibility -->

		<!-- ##################################################### start header ########################################################################################################## -->
		<div style="position: relative"> <!-- fix IE position fixed -->
        <div id="wrapper_global_header"> <!-- start wrapper_global_header -->	
            	
                <header id="wrapper_main_header" class="<?php echo $classbootstraprow;?>"> <!-- start wrapper main header -->
					<div class="span12">		
		            	<!-- start logo -->
		                <div id="logo">
		                	<a href="index.php">
		                    	<?php if($this->params->get('logo','logo_png32.png') == -1): ?>
		                        	<div id="logoNotSelected"></div>
		                   		<?php else: ?>
		                        	<img src="<?php echo $this->baseurl ?>/images/layoutgrafiken/<?php echo $this->params->get('logo','logo.png')?>" alt="<?php echo htmlspecialchars($templateparams->get('sitetitle')); ?>" title="<?php echo htmlspecialchars($templateparams->get('sitetitle')); ?>"  />
		                   		<?php endif; ?>
		               		</a>
		           		</div>
		            	<!-- end logo-->
		                            
		              	<!-- start navtop -->
					   	<?php if ($this->countModules('navtop')) : ?> 
			            	<div id="navtop">
			            		<jdoc:include type="modules" name="navtop" style="none"/> <!-- modul position navtop -->
			            	</div>
					    <?php endif;  ?>
		            	<!-- end navtop -->
		                            
		                            
		               	<!-- start sublogo --> 
		               	<?php  if(($templateparams->get('sublogo-select', 0) == 1  || $this->countModules('top-02' )) && $frontpage == 1):  // Position f�r die Karte �ber dem Headerbild?> 
		                	<div id="wrap_top_02">
		                   		<?php if($this->countModules('top-02')) : ?>
		                        	<jdoc:include type="modules" name="top-02" style="xhtml"/> <!-- module position top-02 -->
		                       	<?php else : ?>
			                    	<img src="<?php echo $this->baseurl ?>/images/header_maps/<?php echo $this->params->get('sublogo'); ?>" alt="<?php echo JText::_('TPL_CO_FREIENSTEINAU_3_SUBLOGO'); ?>" title="<?php echo JText::_('TPL_CO_FREIENSTEINAU_3_SUBLOGO'); ?>" />
			                    <?php endif; ?> 
		                	</div>  
		                	<!-- start background sublogo -->
		                	<div class="opacity grey" id="sublogo_positioning"></div>
		                	<!-- end background sublogo -->
		               	<?php endif; ?> 
		                <!-- end sublogo -->
		                            
			           	<!-- start headerbild -->
                        
                            <?php 
							$headerimg_suffix = '';
							if ($frontpage != 1) { 
							    $headerimg =  $this->params->get('headerimg-sub', 'headerimg_default_sub.jpg');
							    $headerimg_suffix = '_sub';
							} else {
								$headerimg =  $this->params->get('headerimg', 'headerimg_default.jpg');
							} ?>
                                 
		                	<?php if( $templateparams->get('headerimg-select', 0) == 1  || $this->countModules('headerimage' ) ): ?>
		                   		<div id="wrapper_headerimg<?php echo $headerimg_suffix;?>">
		                    		<?php if($this->countModules('headerimage')) : ?>
		                           		<jdoc:include type="modules" name="headerimage" style="none"/> <!-- module position Headerimg -->
		                           	<?php else : ?>
                                         
                                    
		                           		<img src="<?php echo $this->baseurl ?>/images/headerimg/<?php echo $headerimg; ?>" alt="<?php echo JText::_('TPL_CO_FREIENSTEINAU_3_HEADERIMG'); ?>" title="<?php echo JText::_('TPL_CO_FREIENSTEINAU_3_HEADERIMG'); ?>" />
		                           	<?php endif; ?> 
		                      	</div>
						   	<?php endif; ?>                        
						<!-- end headerbild  -->
					</div>
				
               </header> 
       
            
              <!-- start Navmain -->
			  <?php  
              if ($this->countModules('navmain')) :?>
                  <nav id="wrapper_menu_main" class="<?php echo$classbootstraprow;?> role="navigation"">	
                      <div id=" mainmenu" class="span12">
                        <jdoc:include type="modules" name="navmain" style="none" /> <!-- module position navmain --> 
                      </div>       
                  </nav>
              <?php endif; ?>
              <!-- end Navmain --> 
                       
            
           <div class="clearen"></div>    
		
	</div> <!-- end wrapper_global_header -->
    </div>        
<!-- ##################################################### start content ########################################################################################################## -->                

	<div id="content" class="wrapper_global_content" style="<?php if (!$frontpage) { echo 'z-index: 0;';} ?>"> <!-- start wrapper_global_header -->	
		<div id="wrapper_inner_content" class="wrapper_inner"> <!-- start wrapper_inner_header -->		
			<div id="wrapper_main_content">
				<!-- wrapper main-inner  sidebar left +  content  +  sidebar right -->
			  	<div id="wrapper_main_inner" class="<?php echo $classbootstraprow;?>">

                          
						
						<?php  if ($this->countModules('breadcrumb') && $frontpage == 1) : ?> 
		                <!--  start Breadcrumb (frontpage) -->
                        	<div id="wrapper_breadcrumbs">        
			                	<div class="span12">
			                		<jdoc:include type="modules" name="breadcrumb" style="none"/> <!-- module position Breadcrumb (frontpage) -->
			                	</div>
			                </div>
                        <!-- end Breadcrumb (frontpage) -->
	              		<?php endif;  ?>
	             		
             
		               	<?php if ($this->params->get('fontsize') == 1 && $frontpage == 1) : ?>
    		             	<!-- start fontsize (frontpage) -->  
  	                        <div id="wrapper_fontsize">
			               		<div id="fontsize" class="hidden-phone  hidden-tablet <?php if ($bootstrap) echo "span12"; ?>"></div> <!-- frontpage fontsize-->
			               	</div>
                            <!-- end fontsize (frontpage) --> 
		               	<?php endif; ?>
		               	
               
                		<?php if($showleftColumn) : ?>
                			<div id="left"></div>  
                
							<!-- start sidebar left-->
	               		
	                			<section id="outer_sidebar_left" class="leftpositions span3>" >
				                   
									<?php if ($frontpage == 1): ?>
                                    <!-- start Suche (frontpage) -->
						           	<?php  if ($this->countModules('searchleft')) : ?> 
                                    <div id="suchen" class="<?php echo $classbootstraprow;?>"> 				                
						           	<div id="searchleft" class="span12">   
					        		<jdoc:include type="modules" name="searchleft" style="none" /> <!-- module position suchen (frontpage) -->
						               	</div></div>
					            	<?php endif; ?> 
					               	<!-- end Suche  (frontpage)-->
									<?php endif; ?>
					               	
				               
				               		
		                			<?php if($this->countModules('navleft')) : ?> 		
		               				<!-- start navleft -->
                                    <div id="navleft" class="<?php echo $classbootstraprow;?>">
		               					<div class="span12">
                                    		<jdoc:include type="modules" name="navleft" /> <!-- module position Navleft-->
		               					</div>
                                    </div>
                                    <!-- end navleft -->
		                			<?php endif; ?>
		                			
			                    
			                    	<?php  if ($this->countModules('leftpos1')) : ?>
			                    		<div id="leftpos1" class="<?php echo $classbootstraprow;?>">
					                    	<div class="span12">
											<?php if ($this->params->get('modleft') == 1 ) : ?>                                       
					                     		<jdoc:include type="modules" name="leftpos1" style="slider" /> <!-- module position leftpos1 (slider) -->
		                        		 	<?php else : ?>
		                     					<jdoc:include type="modules" name="leftpos1" style="rounded" /> <!-- module position leftpos1 (rounded)-->
		                    			 	<?php endif; ?> 
	                    			 	</div></div>
	                    			<?php endif; ?>             			 	
               			 
		                			<?php if ($this->countModules('leftpos2')) : ?>
					                	<div id="leftpos2" class="<?php $classbootstraprow;?>">
					                		<div class="span12">
											<?php if ($this->params->get('modleft') == 1 ) : ?>                                       
				                     		<jdoc:include type="modules" name="leftpos2" style="slider" /> <!-- module position leftpos2 (slider) -->
	                        		 	<?php else : ?>
	                     					<jdoc:include type="modules" name="leftpos2" style="rounded" /> <!-- module position leftpos2 (rounded)-->
	                    			 	<?php endif; ?>
						                </div></div>  
		                			<?php endif; ?>
               					
			               		</section>
			   			<?php endif; ?> 
                        
           
                        <?php if ($frontpage != 1 ):   //  Fontsize und search wenn keine frontpage ?>
                        
                        <?php if ( $showleftColumn ) {
							           $classbootstrap   = 9;
									   $classbootstrap3  = 8;
									   $classbootstrap2  = 4;
						       } else { $classbootstrap = 12;
										$classbootstrap3  = 9;
									    $classbootstrap2  = 3;}
								  ?>
								  
   		             	<section id="container-content-0" class="span<?php $classbootstrap;?>">
	                	   <div class="<?php echo $classbootstraprow; ?>">
						
						<?php  if ($this->countModules('breadcrumb2') && $frontpage != 1) :  // start Breadcrumb (not frontpage)?> 
		                	<div id="wrapper_breadcrumbs2" class="<?php echo $classbootstraprow;?>">        
			                	<div class="span12">
			                		<jdoc:include type="modules" name="breadcrumb2" style="none"/> 
			                	</div>
			                </div>
	             		<!-- end Breadcrumb (frontpage) -->
	              		<?php endif;  ?>

                     
			          	<div id="wrapper_fontsize" class="<?php echo $classbootstraprow; ?>">
						 <!-- start fontsize  -->  
				       	<?php if ($this->params->get('fontsize') == 1 && $frontpage == 0) : ?>
			               		<div id="fontsize" class="fontsize_right hidden-phone hidden-tablet span<?php echo $classbootstrap2. ' offset' . $classbootstrap3;?>"></div>
		            	<?php endif; ?>
								        
				      		</div>
                        <!-- end fontsize --> 
			        	
                        <!-- Suche rechts -->
		               	<?php  if ($this->countModules('searchright')) : ?> 
		               	<div id="suchen" class="<?php echo $classbootstraprow; ?>">     
		               		<div id="searchright" class="span<?php echo $classbootstrap2. ' offset' . $classbootstrap3;?>">   
                    		<jdoc:include type="modules" name="searchright" style="none" /> 
			               	</div>
		               	</div>
		               		<?php endif; ?>
                        <!-- Ende Suche rechts -->
                       
                        
			     		<?php endif; ?>
                  
              			<!-- start container-content Articles   -->
                       <?php $classbootstrap2 = 3;
						
                       if ($frontpage != 1 ) :        // wenn keine frontpage bootstrap klassen?>
						<div class="<?php echo $classbootstraprow ;?>">
                        
                         <?php
						 if ( $showleftColumn  && $showrightColumn ) {
							 $contentwidth = "spalten2";						 
						     $classbootstrap = 8;
							 $classbootstrap2 = 4;
							 
						        } elseif  ( $showrightColumn && !$showleftColumn )  {
									 $classbootstrap = 9;
									 $classbootstrap2 = 3;
									 $contentwidth = "spalten2"; 
							       } else {
									 $classbootstrap = 12;
 									 $contentwidth = "spalten1";
								  }
							 
					     endif; ?>
						
						  
                        <section id="container-content" class="span<?php $classbootstrap;?>">
		              	
                        <noscript>
			            <!--   Anzeige wenn kein JavaScript -->        
			           	<div class="fehler"><?php echo JText::_('TPL_CO_FREIENSTEINAU_3_NOSCRIPT'); ?></div>
			            <!--   Ende  -->
		              	</noscript>
                
                		
		              	<jdoc:include type="message" />
		              	
		              	
		              	<?php  if ($this->countModules('beforecontent')) : ?>         
		               	<div id="wrapper_beforecontent">
		              		<jdoc:include type="modules" name="beforecontent" style="xhtml"/> <!-- module position vorInhalt -->
			            </div>
		             	<?php endif;  ?>
		              	 
		              	<div class="clearen"></div>

						<?php
						if ($frontpage == 1):  // nur Startseite!!!?>
                      	<?php include_once JPATH_THEMES . '/' . $this->template . '/frontpagemodules.php'; // load frontpagemodules.php?>
						<?php endif; ?>
                        
                        <jdoc:include type="component" />
                                               
                        <div class="clearen"></div>
                        <?php  if ($this->countModules('aftercontent')) : ?>         
                        <div id="wrapper_aftercontent">
                            <jdoc:include type="modules" name="aftercontent" style="xhtml" /> <!-- module position nachInhalt --> 
                        </div>
                        <?php endif;  ?>
						
                        </section>	
					<!-- end container-content --> 
                     
                   
                    <?php if($showrightColumn) : ?>
                    	<div id="right"></div>
                        
                    	<?php if ( $frontpage == 1 ) { $classbootstrap2 = 3; } ?> 
						   
                             
                    	
                        <section id="outer_sidebar_right" class="span<?php echo $classbootstrap2 ;?>">
				                <?php  if ($this->countModules('rightpos1 or infobox')) : ?> 
				                <div class="<?php echo $classbootstraprow; ?>">
				                	<div id="wrapper_rightpos1" class="span12">

									   <?php  if ($this->countModules('infobox')) :  // Infobox fixed ?> 
									   
										   <div id="<?php echo ( $frontpage == 1 ) ? 'infoboxen-front' : 'infoboxen'; ?>">                                        
                                           <jdoc:include type="modules" name="infobox" style="xhtml" />
                                           </div>
                                        
										<?php  endif;  //  ende infobox ?>
                                        
										<?php if ($this->params->get('modright') == 1 ) : ?>                                       
				                     		<jdoc:include type="modules" name="rightpos1" style="slider" /> <!-- module position rightpos1 --> 
					                  	<?php else : ?>
					                    	<jdoc:include type="modules" name="rightpos1" style="xhtml" /> <!-- module position rightpos1 --> 
					                    <?php endif; ?>
                                       
				                    </div>
				                </div>
			                    <?php endif; ?>
	                              
	                           	<?php  if ($this->countModules('rightpos2')) : ?> 
	                           	<div class="<?php echo $classbootstraprow; ?>">
				                	<div id="wrapper_rightpos2" class="span12">
										<?php if ($this->params->get('modright') == 1 ) : ?>                                       
				                     		<jdoc:include type="modules" name="rightpos2" style="slider" /> <!-- module position rightpos2 --> 
					                  	<?php else : ?>
					                    	<jdoc:include type="modules" name="rightpos2" style="xhtml" /> <!-- module position rightpos2 --> 
					                    <?php endif; ?>
				                    </div>
				                </div>
			                    <?php endif; ?>  
				                <div class="clearen"></div>
                        </section>
                               
                    <?php endif; ?> 
                   <!-- end sidebar right -->
                
                  <?php if ($frontpage != 1 )  { echo '</div></div></div>';} ?>
               		
			</div>  <!-- end wrapper main_inner -->
		</div> <!-- ende wrapper_main_content  -->
        
        <?php  if ($this->countModules('bottom-01')) : ?>
		<!-- Module bottom  -->   
        	<div id="wrapper_bottom-01" class="<?php echo $classbootstraprow; ?>" >
        		<div class="span12">
        			<jdoc:include type="modules" name="bottom-01" style="xhtml" /> <!-- module position bottom-01 TODO: wieso style none? -->
        		</div>
        	</div>
        <?php endif; ?> 
    
		</div> <!-- end wrapper_inner_content -->
	</div> <!-- end wrapper_global_content -->  
</div>  	
<!-- ##################################################### start footer ########################################################################################################## -->  
 
	<div id="wrapper_global_footer"> <!-- start wrapper_global_header -->	
		<div id="wrapper_inner_footer" class="wrapper_inner <?php if ($bootstrap) echo $classbootstrapcontainer; ?>"> <!-- start wrapper_inner_header -->	 
        <?php
		  $ID_footerA = "wrapper_footer_outer";
		  $ID_footerB = "footer";
		  $ID_footerC = "wrap_footer_inner";
        ?>
          
        <!-- <div id="<?php //echo $ID_footerA; ?>" class="phone-nobackground <?php //if ($bootstrap) echo $classbootstraprow;?>" > --> <!-- start wrapper footer outer -->
            
            <?php if (!$templateparams->get('html5', 0)): ?> <!-- start footer -->
                <div id="<?php echo $ID_footerB; ?>" class="phone-nobackground <?php if ($bootstrap) echo $classbootstraprow; ?>" > 
          	<?php else: ?>
                <footer id="<?php echo $ID_footerB; ?>" class="phone-nobackground <?php if ($bootstrap) echo $classbootstraprow; ?>">
           	<?php endif; ?>
                

                	<div id="<?php echo $ID_footerC; ?>" class="phone-nobackground span12">
                   		<?php if($this->countModules('footertop')) : ?>   
                      	<div <?php if ($bootstrap) echo 'class="'. $classbootstraprow. '"';?>>
                        	<div id="wrapper_footertop" <?php if ($bootstrap) echo 'clas="span12"'; ?>>
                        		<jdoc:include type="modules" name="footertop" style="rounded"/> <!-- module position footertop -->
                        	<div class="clearen"></div>
                     		</div>
                      	</div>
                      	<?php endif; ?>

                      	<!-- start footer inner-->
                      	<div id="footer_inner" <?php if ($bootstrap) echo 'class="'. $classbootstraprow. '"';?>> 
                      		<?php if ($this->countModules('footerCol1innerCol1') && $this->countModules('footerCol1innerCol2')) : ?>
			                	<div <?php if ($bootstrap) echo 'class="span3"';?> >
		                    		<jdoc:include type="modules" name="footerCol1innerCol1" style="rounded"/> <!-- module position footerCol1innerCol1 -->
			                  	</div>
			                 	<div <?php if ($bootstrap) echo 'class="span3"';?> >
		                    		<jdoc:include type="modules" name="footerCol1innerCol2" style="rounded"/> <!-- module position footerCol1innerCol2 -->
			                  	</div>
                      		<?php elseif($this->countModules('footerCol1innerCol1')) : ?>   
			                	<div <?php if ($bootstrap) echo 'class="span6"';?> >
		                    		<jdoc:include type="modules" name="footerCol1innerCol1" style="rounded"/> <!-- module position footerCol1innerCol1 -->
			                  	</div>
			                <?php elseif ($this->countModules('footerCol1innerCol2')) : ?>
			                	<div <?php if ($bootstrap) echo 'class="span6"';?> >
		                    		<jdoc:include type="modules" name="footerCol1innerCol2" style="rounded"/> <!-- module position footerCol1innerCol2 -->
			                  	</div>
			                <?php elseif($this->countModules('footerCol1innerCol1')) : ?>   
			                	<div <?php if ($bootstrap) echo 'class="span6"';?> >
		                    		<jdoc:include type="modules" name="footerCol1innerCol1" style="rounded"/> <!-- module position footerCol1innerCol1 -->
			                  	</div>
		                  	<?php else: ?>
	                      		<div <?php if ($bootstrap) echo 'class="span6"';?>></div>
		                   	<?php endif; ?>
		
		                   	<?php if($this->countModules('footerCol2')) : ?> 
			                  	<div <?php if ($bootstrap) echo 'class="span6"';?>>
			                    	<jdoc:include type="modules" name="footerCol2" style="rounded"/> <!-- module position footerCol2 -->
			                   	</div>
		                   	<?php else: ?>
		                      	<div <?php if ($bootstrap) echo 'class="span6"';?>></div>
		                   	<?php endif; ?> 
                      	</div>
            		</div> <!-- end wrap_footer inner -->

            <?php if (!$templateparams->get('html5', 0)): ?>  <!-- end footer -->
            	</div> 
           	<?php else: ?>
                <?php echo ' </footer>' ?>
           	<?php endif; ?>            

     		 <!-- </div> end wrapper footer outer -->  
		</div> <!-- end wrapper_inner_footer -->
	</div> <!-- end wrapper_global_footer -->  
	
	<div ><a  id="gototop" class="no-print" href="#seitenanfang" title="<?php echo JText::_('TPL_CO_FREIENSTEINAU_3_TOTOPTITLE'); ?>"><?php echo JText::_('TPL_CO_FREIENSTEINAU_3_TOTOP'); ?></a></div>


</div> <!-- end wrapper global -->

<!--  Template copyright das webconcept   www.das-webconcept.de  2015             -->


<?php if($templateparams->get('fontsize', 0) == 1): ?>
		<script type="text/javascript">
		var fontSizeTitle='<?php echo JText::_('TPL_CO_FREIENSTEINAU_3_FONTSIZE', true); ?>';
		var bigger='<?php echo JText::_('TPL_CO_FREIENSTEINAU_3_BIGGER', true); ?>';
		var reset='<?php echo JText::_('TPL_CO_FREIENSTEINAU_3_RESET', true); ?>';
		var smaller='<?php echo JText::_('TPL_CO_FREIENSTEINAU_3_SMALLER', true); ?>';
		var biggerTitle='<?php echo JText::_('TPL_CO_FREIENSTEINAU_3_INCREASE_SIZE', true); ?>';
		var resetTitle='<?php echo JText::_('TPL_CO_FREIENSTEINAU_3_REVERT_STYLES_TO_DEFAULT', true); ?>';
		var smallerTitle='<?php echo JText::_('TPL_CO_FREIENSTEINAU_3_DECREASE_SIZE', true); ?>';
		</script>

<?php endif; ?>

<script type="text/javascript" src="<?php echo $tpath;?>/js/funktionen.js"></script>

<?php 

if ( $footable == 1 ) : ?>
	   <!-- Responsive Tabellen  -->
	   <script type="text/javascript" src="<?php echo $tpath;?>/footable/js/footable.js"></script>
	   <script type="text/javascript">
				   jQuery(function () {
				   jQuery('.footable').footable();
				  });
	   </script>
<?php endif; ?>
    

<?php if ($this->countModules('infobox')) : ?>

<script type="text/javascript">
/* <![CDATA[ */
( function($) {
$(document).ready(function() {
    var top = $('#infoboxen').offset().top - parseFloat($('#infoboxen').css('marginTop').replace(/auto/, 0));
    var footTop = $('#wrapper_global_footer').offset().top - parseFloat($('#wrapper_global_footer').css('marginTop').replace(/auto/, 0));
    var maxY = footTop - $('#infoboxen').outerHeight();

    $(window).scroll(function(evt) {
        var y = $(this).scrollTop();
        if (y > top) {
            if (y < maxY) {
                $('#infoboxen').addClass('fixed').removeAttr('style');
            } else {
                $('#infoboxen').removeClass('fixed').css({
                    position: 'absolute',
                    top: (maxY - top) + 'px'
                });
            }
        } else {
            $('#infoboxen').removeClass('fixed');
        }
    });
}) 
})(jQuery);
/* ]]> */
</script>

<?php endif; ?>
</body>
<!-- ############################# end html body ###################################################################################-->
</html>
